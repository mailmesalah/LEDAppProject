﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

using Windows.Networking.Sockets;
using Windows.Storage.Streams;
using System.Threading;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace LEDApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private int ledStateMain = 0x0f;
        private int ledStateRemote = 0x00;
        private MessageWebSocket messageWebSocket;
        private DataWriter messageWriter;

        private async void UpdateLEDs()
        {
            try
            {
                // Make a local copy to avoid races with Closed events.
                MessageWebSocket webSocket = messageWebSocket;

                // Have we connected yet?
                if (webSocket == null)
                {
                    Uri server = new Uri("ws://192.168.1.88");

                    webSocket = new MessageWebSocket();
                    // MessageWebSocket supports both utf8 and binary messages.
                    // When utf8 is specified as the messageType, then the developer
                    // promises to only send utf8-encoded data.
                    webSocket.Control.MessageType = SocketMessageType.Utf8;
                    // Set up callbacks
                    webSocket.MessageReceived += MessageReceived;
                    webSocket.Closed += Closed;

                    await webSocket.ConnectAsync(server);
                    messageWebSocket = webSocket; // Only store it after successfully connecting.
                    messageWriter = new DataWriter(webSocket.OutputStream);
                }
                messageWriter.WriteByte((byte)ledStateMain);
                messageWriter.WriteByte((byte)ledStateRemote);

                // Send the data as one complete message.
                await messageWriter.StoreAsync();

            }
            catch (Exception ex) // For debugging
            {
//                WebErrorStatus status = WebSocketError.GetStatus(ex.GetBaseException().HResult);
                // Add your specific error-handling code here.
            }
        }
        private void MessageReceived(MessageWebSocket sender, MessageWebSocketMessageReceivedEventArgs args)
        {
            try
            {
                using (DataReader reader = args.GetDataReader())
                {
                    reader.UnicodeEncoding = Windows.Storage.Streams.UnicodeEncoding.Utf8;
                    string read = reader.ReadString(reader.UnconsumedBufferLength);
                }
            }
            catch (Exception ex) // For debugging
            {
//                WebErrorStatus status = WebSocketError.GetStatus(ex.GetBaseException().HResult);
                // Add your specific error-handling code here.
            }
        }
        private void Closed(IWebSocket sender, WebSocketClosedEventArgs args)
        {
            // You can add code to log or display the code and reason
            // for the closure (stored in args.Code and args.Reason)

            // This is invoked on another thread so use Interlocked 
            // to avoid races with the Start/Close/Reset methods.
            MessageWebSocket webSocket = Interlocked.Exchange(ref messageWebSocket, null);
            if (webSocket != null)
            {
                webSocket.Dispose();
            }
        }

        public MainPage()
        {
            this.InitializeComponent();

            this.NavigationCacheMode = NavigationCacheMode.Required;
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            // TODO: Prepare page for display here.

            // TODO: If your application contains multiple pages, ensure that you are
            // handling the hardware Back button by registering for the
            // Windows.Phone.UI.Input.HardwareButtons.BackPressed event.
            // If you are using the NavigationHelper provided by some templates,
            // this event is handled for you.
        }

        private void TextBlock_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void TextBlock_SelectionChanged_1(object sender, RoutedEventArgs e)
        {

        }

        private void UpdateLEDStatus()
        {
            UpdateLEDs();
        }

        private void buttonMainR_Tapped(object sender, TappedRoutedEventArgs e)
        {
            ledStateMain ^= 0x01;

            if ((ledStateMain & 0x01) != 0)
                buttonMainR.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 203, 21, 21));
            else
                buttonMainR.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 0, 0, 0));
            UpdateLEDStatus();
        }

        private void buttonMainB_Tapped(object sender, TappedRoutedEventArgs e)
        {
            ledStateMain ^= 0x02;

            if ((ledStateMain & 0x02) != 0)
                buttonMainB.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 27, 44, 153));
            else
                buttonMainB.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 0, 0, 0));
            UpdateLEDStatus();
        }

        private void buttonMainG_Tapped(object sender, TappedRoutedEventArgs e)
        {
            ledStateMain ^= 0x04;

            if ((ledStateMain & 0x04) != 0)
                buttonMainG.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 24, 137, 34));
            else
                buttonMainG.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 0, 0, 0));
            UpdateLEDStatus();
        }

        private void buttonMainO_Tapped(object sender, TappedRoutedEventArgs e)
        {
            ledStateMain ^= 0x08;

            if ((ledStateMain & 0x08) != 0)
                buttonMainO.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 240, 120, 1));
            else
                buttonMainO.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 0, 0, 0));
            UpdateLEDStatus();
        }

        private void buttonRemoteR_Tapped(object sender, TappedRoutedEventArgs e)
        {
            ledStateRemote ^= 0x01;

            if ((ledStateRemote & 0x01) != 0)
                buttonRemoteR.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 203, 21, 21));
            else
                buttonRemoteR.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 0, 0, 0));
            UpdateLEDStatus();
        }

        private void buttonRemoteG_Tapped(object sender, TappedRoutedEventArgs e)
        {
            ledStateRemote ^= 0x02;

            if ((ledStateRemote & 0x02) != 0)
                buttonRemoteG.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 24, 137, 34));
            else
                buttonRemoteG.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 0, 0, 0));
            UpdateLEDStatus();
        }

        private void buttonRemoteB_Tapped(object sender, TappedRoutedEventArgs e)
        {
            ledStateRemote ^= 0x04;

            if ((ledStateRemote & 0x04) != 0)
                buttonRemoteB.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 27, 44, 153));
            else
                buttonRemoteB.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 0, 0, 0));
            UpdateLEDStatus();
        }

        private void buttonRemoteY_Tapped(object sender, TappedRoutedEventArgs e)
        {
            ledStateRemote ^= 0x08;

            if ((ledStateRemote & 0x08) != 0)
                buttonRemoteY.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 220, 203, 26));
            else
                buttonRemoteY.Background = new SolidColorBrush(Windows.UI.Color.FromArgb(255, 0, 0, 0));
            UpdateLEDStatus();
        }
    }
}
